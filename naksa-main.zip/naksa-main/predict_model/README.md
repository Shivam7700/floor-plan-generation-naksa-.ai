# Download
the model and parameters can be downloaded in <https://www.dropbox.com/scl/fi/xvcqof1r1uiy45ziwws8l/predict_model.rar?rlkey=aq2ibm1kw2d35i63olqj0dm4x&st=62pq13rv&dl=0>