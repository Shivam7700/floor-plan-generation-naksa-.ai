Use LLM to convert prompt to json format

## Json format description

Type：LivingRoom, MasterRoom, Kitchen, Bathroom, DiningRoom, ChildRoom, StudyRoom, SecondRoom, GuestRoom, Balcony, Entrance, Storage.

Location: north, northwest, west, southwest, south, southeast, east, northeast, cener

Size: XL, L, M, S, XS. (The value of this property is calculated as a proportion of the entire layout outline.)
